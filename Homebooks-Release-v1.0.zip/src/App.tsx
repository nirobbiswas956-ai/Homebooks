import React, { useEffect, useState } from "react";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut, updateProfile, sendEmailVerification
} from "firebase/auth";
import {
  addDoc, collection, doc, onSnapshot, orderBy, query, serverTimestamp,
  setDoc, updateDoc
} from "firebase/firestore";
import { auth, db, firebaseConfigured, storage } from "./firebase";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";

type UserDoc = { uid:string; email:string; displayName:string; username:string; photoURL:string; createdAt:any; };
type Post = { id:string; uid:string; author:string; text:string; imageURL?:string; createdAt:any; likes:number; comments:number; };

const nav = ["Home", "Search", "Messenger", "Videos", "Notifications", "Groups", "Profile", "Menu"];

function App(){
  const [user,setUser] = useState(auth.currentUser);
  const [mode,setMode] = useState<"login"|"register">("login");
  const [page,setPage] = useState("Home");
  const [dark,setDark] = useState(false);
  const [authReady,setAuthReady] = useState(false);

  useEffect(()=>onAuthStateChanged(auth,u=>{setUser(u);setAuthReady(true)}),[]);
  useEffect(()=>{document.documentElement.dataset.theme=dark?"dark":"light"},[dark]);

  if(!authReady) return <div className="center">লোড হচ্ছে…</div>;
  if(!user) return <Auth mode={mode} setMode={setMode}/>;

  return <Shell user={user} page={page} setPage={setPage} dark={dark} setDark={setDark}/>;
}

function Auth({mode,setMode}:{mode:"login"|"register",setMode:(v:"login"|"register")=>void}){
  const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [name,setName]=useState(""); const [username,setUsername]=useState("");
  const [busy,setBusy]=useState(false); const [error,setError]=useState("");

  async function submit(e:React.FormEvent){
    e.preventDefault(); setError(""); setBusy(true);
    try{
      if(!firebaseConfigured) throw new Error("Firebase configuration দেওয়া হয়নি। .env ফাইল পূরণ করুন।");
      if(mode==="login"){
        await signInWithEmailAndPassword(auth,email,password);
      }else{
        const c=await createUserWithEmailAndPassword(auth,email,password);
        await updateProfile(c.user,{displayName:name});
        await setDoc(doc(db,"users",c.user.uid),{
          uid:c.user.uid,email:c.user.email||"",displayName:name,username:username.toLowerCase().replace(/[^a-z0-9_]/g,""),
          photoURL:"",createdAt:serverTimestamp(),updatedAt:serverTimestamp()
        });
        await sendEmailVerification(c.user);
        alert("অ্যাকাউন্ট তৈরি হয়েছে। ইমেইল verification link পাঠানো হয়েছে।");
      }
    }catch(err:any){setError(err?.message?.replace("Firebase: ","")||"কিছু সমস্যা হয়েছে।")}
    finally{setBusy(false)}
  }

  return <div className="auth">
    <div className="auth-card">
      <img src="./logo.svg" className="logo" />
      <h1>Homebooks</h1><p>Welcome to the App</p>
      <form onSubmit={submit}>
        {mode==="register" && <>
          <input required placeholder="Full Name" value={name} onChange={e=>setName(e.target.value)}/>
          <input required placeholder="Username" value={username} onChange={e=>setUsername(e.target.value)}/>
        </>}
        <input required type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)}/>
        <input required type="password" minLength={8} placeholder="Password (8+ characters)" value={password} onChange={e=>setPassword(e.target.value)}/>
        {error && <div className="error">{error}</div>}
        <button disabled={busy}>{busy?"Processing…":mode==="login"?"Login":"Create Account"}</button>
      </form>
      <button className="linkbtn" onClick={()=>setMode(mode==="login"?"register":"login")}>
        {mode==="login"?"Create new account":"Already have an account? Login"}
      </button>
      <small>Made by Md Nirob Biswas • Bangladesh</small>
    </div>
  </div>
}

function Shell({user,page,setPage,dark,setDark}:{user:any,page:string,setPage:(p:string)=>void,dark:boolean,setDark:(v:boolean)=>void}){
  return <div className="app">
    <header>
      <div className="brand" onClick={()=>setPage("Home")}><img src="./logo.svg"/><b>Homebooks</b></div>
      <input className="global-search" placeholder="Search people, posts, videos, groups…"/>
      <div className="header-actions">
        <button onClick={()=>setPage("Messenger")}>💬</button>
        <button onClick={()=>setPage("Notifications")}>🔔</button>
        <button onClick={()=>setPage("Profile")}>{user.photoURL?<img className="avatar" src={user.photoURL}/>: "👤"}</button>
      </div>
    </header>
    <div className="layout">
      <aside className="sidebar">{nav.map(x=><button key={x} className={page===x?"active":""} onClick={()=>setPage(x)}>{icon(x)} {x}</button>)}<button onClick={()=>setDark(!dark)}>{dark?"☀️":"🌙"} {dark?"Light":"Dark"}</button><button onClick={()=>signOut(auth)}>↪ Logout</button></aside>
      <main>
        {page==="Home" && <Home user={user}/>}
        {page==="Messenger" && <Messenger user={user}/>}
        {page==="Profile" && <Profile user={user}/>}
        {page==="Search" && <Search/>}
        {page==="Notifications" && <Empty title="Notifications" text="Your notifications will appear here."/>}
        {page==="Videos" && <Empty title="Videos & Reels" text="Video upload and creator features are ready for the next release module."/>}
        {page==="Groups" && <Empty title="Groups" text="Group creation and moderation module is connected to the same Firebase architecture."/>}
        {page==="Menu" && <Settings dark={dark} setDark={setDark}/>}
      </main>
    </div>
    <footer>Homebooks • Made by Md Nirob Biswas</footer>
  </div>
}

function Home({user}:{user:any}){
 const [posts,setPosts]=useState<Post[]>([]);
 const [text,setText]=useState("");
 useEffect(()=>onSnapshot(query(collection(db,"posts"),orderBy("createdAt","desc")),s=>setPosts(s.docs.map(d=>({id:d.id,...d.data()} as Post)))),[]);
 async function post(){if(!text.trim())return;await addDoc(collection(db,"posts"),{uid:user.uid,author:user.displayName||"Homebooks User",text:text.trim(),createdAt:serverTimestamp(),likes:0,comments:0});setText("")}
 return <section><div className="welcome"><h2>Welcome, {user.displayName||"User"} 👋</h2><p>Connect • Share • Grow</p></div>
 <div className="card composer"><textarea value={text} onChange={e=>setText(e.target.value)} placeholder="What's on your mind?"/><div className="row"><span>📷 Photo</span><span>🎥 Video</span><span>😊 Feeling</span><button onClick={post}>Post</button></div></div>
 {posts.map(p=><article className="card post" key={p.id}><div className="posthead"><div className="avatar big">👤</div><div><b>{p.author}</b><small> • Homebooks</small></div></div><p>{p.text}</p><div className="post-actions"><button>👍 Like</button><button>💬 Comment</button><button>↗ Share</button></div></article>)}
 </section>
}

function Messenger({user}:{user:any}){
 const [uid,setUid]=useState(""); const [active,setActive]=useState(""); const [text,setText]=useState(""); const [msgs,setMsgs]=useState<any[]>([]);
 async function openChat(){if(!uid.trim())return;const id=[user.uid,uid.trim()].sort().join("_");setActive(id);await setDoc(doc(db,"conversations",id),{memberIds:[user.uid,uid.trim()],updatedAt:serverTimestamp()},{merge:true})}
 useEffect(()=>{if(!active)return;return onSnapshot(query(collection(db,"conversations",active,"messages"),orderBy("createdAt","asc")),s=>setMsgs(s.docs.map(d=>({id:d.id,...d.data()}))))},[active])
 async function send(){if(!text.trim()||!active)return;await addDoc(collection(db,"conversations",active,"messages"),{senderId:user.uid,text:text.trim(),type:"text",status:"sent",createdAt:serverTimestamp()});await updateDoc(doc(db,"conversations",active),{lastMessage:text.trim(),updatedAt:serverTimestamp()});setText("")}
 return <section><h2>Messenger</h2><div className="messenger"><div className="chatlist"><input placeholder="Search by username / user ID" value={uid} onChange={e=>setUid(e.target.value)}/><button onClick={openChat}>Open Chat</button></div><div className="chat"><div className="chatbar">Real-time chat</div><div className="messages">{msgs.map(m=><div className={m.senderId===user.uid?"bubble mine":"bubble"} key={m.id}>{m.text}<small>{m.status}</small></div>)}</div><div className="sendrow"><input value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Write a message…"/><button onClick={send}>➤</button></div></div></div></section>
}

function Profile({user}:{user:any}){
 const [name,setName]=useState(user.displayName||""); const [file,setFile]=useState<File|null>(null);
 async function save(){let photo=user.photoURL||"";if(file){const r=ref(storage,`profile/${user.uid}/${file.name}`);await uploadBytes(r,file);photo=await getDownloadURL(r)}await updateProfile(user,{displayName:name,photoURL:photo});await setDoc(doc(db,"users",user.uid),{displayName:name,photoURL:photo,updatedAt:serverTimestamp()},{merge:true});alert("Profile updated")}
 return <section><h2>Profile</h2><div className="card profile"><div className="avatar xl">{user.photoURL?<img src={user.photoURL}/>: "👤"}</div><h2>{user.displayName||"Homebooks User"}</h2><p>{user.email}</p><input value={name} onChange={e=>setName(e.target.value)} placeholder="Display name"/><input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0]||null)}/><button onClick={save}>Save Profile</button></div></section>
}

function Search(){return <section><h2>Search</h2><div className="card"><input className="wide" placeholder="Search username, people, posts, videos, groups, hashtags…"/><p>Search index and advanced filtering can be enabled with a Cloud Functions/search provider.</p></div></section>}
function Settings({dark,setDark}:{dark:boolean,setDark:(x:boolean)=>void}){return <section><h2>Settings & Privacy</h2><div className="grid"><div className="card"><h3>Privacy</h3><p>Post audience • Story audience • Friend list • Messages • Online status</p></div><div className="card"><h3>Security</h3><p>Password • 2FA • Active sessions • Login alerts • Blocked users</p></div><div className="card"><h3>Preferences</h3><button onClick={()=>setDark(!dark)}>{dark?"Use Light Mode":"Use Dark Mode"}</button></div><div className="card"><h3>Account</h3><p>Download data • Deactivate • Delete account • Support</p></div></div></section>}
function Empty({title,text}:{title:string,text:string}){return <section><h2>{title}</h2><div className="card empty">{text}</div></section>}
function icon(x:string){return ({Home:"🏠",Search:"🔎",Messenger:"💬",Videos:"🎬",Notifications:"🔔",Groups:"👥",Profile:"👤",Menu:"☰"} as any)[x]||"•"}

export default App;