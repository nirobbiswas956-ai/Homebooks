# Homebook — Release Build

Made by **Md Nirob Biswas**, Bangladesh.

## Stack
React + TypeScript + Vite + Firebase + GitHub Pages.

## Before release
1. Create a Firebase project.
2. Enable Authentication → Email/Password.
3. Create Firestore Database.
4. Create Storage.
5. Copy `.env.example` to `.env` and fill the Firebase Web App values.
6. Deploy `firestore.rules` and `storage.rules`.
7. Test registration, email verification, login, profile upload and Messenger with two accounts.
8. Never put Firebase Admin SDK/service-account keys in this repository.

## Local build
npm install
npm run build

## GitHub Pages
Add these repository secrets:
VITE_FIREBASE_API_KEY
VITE_FIREBASE_AUTH_DOMAIN
VITE_FIREBASE_PROJECT_ID
VITE_FIREBASE_STORAGE_BUCKET
VITE_FIREBASE_MESSAGING_SENDER_ID
VITE_FIREBASE_APP_ID

The included workflow builds and deploys `dist`.

## Important
This release has real Firebase-connected authentication, profiles, posts, storage upload and real-time chat foundations. Features requiring privileged backend/provider services (custom 8-digit OTP, FCM, 2FA, voice/video calling, advanced search, full moderation and monetization) must be implemented and tested before advertising them as available.
